If you want to run part 1, run Driver.java
If you want to run part 2, run TSP.java